> # JV Financial Simulation Dashboard

**Author:** Manus AI  
**Date:** 2025-10-18

---

## 1. Overview

This project is an interactive financial simulation dashboard for a Joint Venture (JV) between a developer and Essence Capital. It allows users to model and analyze three operational scenarios for a real estate development project:

- **Build-to-Rent:** All developed properties are refinanced and held for rental income.
- **Build-to-Sell:** All developed properties are sold upon completion.
- **Hybrid:** A mix of properties are rented and sold, allowing for break-even analysis.

The dashboard provides real-time feedback on key financial metrics, enabling strategic decision-making by adjusting a wide range of parameters.

## 2. Features

- **Interactive Simulation:** Adjust over 15 parameters in real-time to see their impact on the financial model.
- **Three Operational Models:** Analyze Build-to-Rent, Build-to-Sell, and Hybrid scenarios.
- **Unit Economics:** Detailed breakdown of costs, profits, and returns for a single property.
- **60-Month Portfolio Simulation:** Project cash flow, fundraising, construction, and profitability over a 5-year period.
- **LTV Sensitivity Analysis:** Visualize the impact of Loan-to-Value (LTV) ratios on DSCR, cash flow, and refinancing shortfalls.
- **Data Export:** Export all parameters, simulation data, and analysis to JSON, CSV, and TXT formats.
- **Scenario Management:** Quickly load preset scenarios (100% Rent, 100% Sell, Hybrid) and save custom configurations.
- **Real-time Alerts:** Visual warnings for critical metrics like low DSCR or refinancing shortfalls.

## 3. Technology Stack

- **Backend & Frontend:** [Streamlit](https://streamlit.io/) (Python)
- **Data Manipulation:** [Pandas](https://pandas.pydata.org/)
- **Numerical Calculations:** [NumPy](https://numpy.org/)
- **Interactive Visualizations:** [Plotly](https://plotly.com/)

This stack was chosen for its ability to rapidly develop a highly interactive and data-intensive web application with a single language (Python).

## 4. Environment Setup

To run the dashboard locally, you need Python 3.9+ and the following packages.

1.  **Clone the repository or download the source code.**

2.  **Install the required packages:**

    ```bash
    pip install streamlit pandas numpy plotly
    ```

3.  **Run the Streamlit application:**

    ```bash
    streamlit run dashboard.py
    ```

    The application will be available at `http://localhost:8501`.

## 5. Explanation of Formulas and Logic

All calculations are based on the provided requirements document. Below are the key formulas implemented in the financial engine.

### Key Formulas Table

| Metric                  | Formula                                                      | Description                                                                 |
| ----------------------- | ------------------------------------------------------------ | --------------------------------------------------------------------------- |
| **Overhead per Unit**   | `(OverheadMonthly * CycleMonths) / TargetSimultaneous`         | Allocates the total overhead cost over the construction cycle to each unit.   |
| **Investor Principal (P)** | `LandCost + FirstDraw + OverheadPerUnit`                     | The initial capital required from the investor per unit.                    |
| **Quarterly Reserve**   | `0.045 * P`                                                  | A reserve fund equal to 4.5% of the investor's principal.                 |
| **Gross Fundraising (G)** | `(P + Reserve) / (1 - CapFeeRate)`                           | The total amount of capital to be raised, accounting for the 5% cap fee.    |
| **Mortgage Payment**    | Excel-compatible `PMT` function                              | Calculates the monthly mortgage payment for a refinanced property.          |
| **DSCR**                | `NOI / MortgagePayment`                                      | Debt Service Coverage Ratio, a measure of cash flow available to pay debt.  |
| **Refi Shortfall**      | `(P * 1.16) - NetRefiCash`                                     | The gap between the amount owed to the investor and the cash from refinancing. |
| **Sell Profit**         | `NetProceeds - (P * 1.16)`                                   | The profit remaining after selling a property and paying back the investor. |

### Investor Distribution Schedule

The investor receives a return based on the following schedule, which totals **16%** of the principal over 12 months:

- **Month 3:** 1.5% of Principal
- **Month 6:** 1.5% of Principal
- **Month 9:** 1.5% of Principal
- **Month 12:** 11.5% of Principal

This follows the explicit distribution schedule from the requirements, although it differs slightly from the "15% a.a." summary line.

## 6. Guide to Usage and Adjustments

The dashboard is organized into four main tabs:

### 📈 Unit Economics

This tab provides a side-by-side comparison of the **Build-to-Rent** and **Build-to-Sell** scenarios for a single property. You can see how changes in the sidebar parameters affect metrics like DSCR, Refi Shortfall, and ROI.

### 🏢 Portfolio Simulation

This tab projects the performance of the entire portfolio over 60 months based on the selected **Rent/Sell Mix**. Key visualizations include:

- **Monthly Fundraising:** See the breakdown of capital raised each month.
- **Active Constructions:** Track the number of simultaneous projects against your target.
- **Cumulative Cash Flow:** Watch the project's cash position over time and identify the **self-sustainability point**.

### 📊 LTV Analysis

This tab is dedicated to sensitivity analysis. It shows how the **LTV ratio** impacts key refinancing metrics. Use these charts to determine the optimal LTV that minimizes shortfalls while maximizing cash flow.

### 💾 Export & Scenarios

Use this tab to:

- **Load Preset Scenarios:** Quickly switch between 100% Rent, 100% Sell, and a 50/50 Hybrid model.
- **Export Data:** Download the current parameters (JSON), full 60-month portfolio data (CSV), or LTV analysis (CSV) for offline analysis.
- **Download Summary:** Get a quick text summary of the current simulation.

## 7. Example Scenarios

Three example scenarios are included in the `scenarios/` directory:

- `100_rent_scenario.json`
- `100_sell_scenario.json`
- `hybrid_breakeven_scenario.json`

These can be loaded into the application to see different outcomes.

