# Distribution Schedule Clarification

## From Requirements Document

The requirements state:
- **Investor APR: 15% a.a.**
- **Quarterly distributions: 1.5% each (months 3, 6, and 9)**
- **Final top-up: 11.5% (month 12)**

## Calculation

If we add up the distributions:
- Month 3: 1.5%
- Month 6: 1.5%
- Month 9: 1.5%
- Month 12: 11.5%
- **Total: 16.0%**

## Analysis

The 16% total represents the **total return** over the 12-month period, which includes:
1. The **principal return** (100%)
2. The **interest/profit** (16%)

However, the requirements explicitly state "15% a.a." as the Investor APR.

## Possible Interpretations

1. **Interpretation A**: The distributions (1.5% x 3 + 11.5% = 16%) are correct as stated, and the "15% APR" is approximate or refers to something else.

2. **Interpretation B**: There's a slight discrepancy in the requirements, and we should use the explicitly stated distribution schedule (which totals 16%).

## Implementation Decision

**We are implementing exactly as specified in the requirements:**
- Quarterly distributions: 1.5% each (months 3, 6, 9)
- Final distribution: 11.5% (month 12)
- **Total interest: 16% over 12 months**

This matches the explicit formula given in section 4 of the requirements:
```
Distribuições:
 Meses 3, 6, 9 → 1,5% × P
 Mês 12 → P + 11,5% × P
```

The final payment at month 12 returns the principal (P) plus 11.5% interest, and combined with the three quarterly payments of 1.5% each, the total interest is 16%.

## Note for User

If the 15% APR is a hard requirement, the distribution schedule would need to be adjusted to:
- Option 1: 1.5% + 1.5% + 1.5% + 10.5% = 15%
- Option 2: 1.25% + 1.25% + 1.25% + 11.25% = 15%

However, we are following the explicit distribution schedule as stated in section 4 of the requirements.

