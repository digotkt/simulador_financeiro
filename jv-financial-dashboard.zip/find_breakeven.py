# find_breakeven.py

import pandas as pd
import numpy as np

# Import calculation functions from the dashboard
from dashboard import (
    calculate_overhead_per_unit,
    calculate_investor_principal,
    calculate_quarterly_reserve,
    calculate_gross_fundraising,
    calculate_cap_fee,
    calculate_rent_metrics,
    calculate_sell_metrics,
    simulate_portfolio_60_months,
)

# Default parameters from the requirements
default_params = {
    "sale_price": 350000,
    "build_cost": 225000,
    "land_cost": 50000,
    "first_draw": 45000,
    "closing_cost_rate": 0.08,
    "cycle_months": 10,
    "overhead_monthly": 10000,
    "cap_fee_rate": 0.05,
    "target_simultaneous": 20,
    "investor_apr": 0.15,
    "ltv_default": 0.70,
    "rent_monthly": 2300,
    "mortgage_annual_rate": 0.075,
    "mortgage_term_years": 30,
    "monthly_non_debt_costs": 300,
    "refi_cost_rate": 0.03,
}

print("Finding break-even rent/sell mix...")

results = []

# Iterate through rent percentages from 0 to 100
for rent_percentage in range(0, 101, 1):
    df, sustainability_month, _, _, _, _ = simulate_portfolio_60_months(
        default_params, rent_percentage
    )
    final_cash = df["cumulative_cash"].iloc[-1]
    results.append({"rent_percentage": rent_percentage, "final_cash": final_cash})

# Find the percentage closest to zero
df_results = pd.DataFrame(results)
breakeven_scenario = df_results.loc[df_results["final_cash"].abs().idxmin()]

breakeven_percentage = int(breakeven_scenario["rent_percentage"])
final_cash_at_breakeven = breakeven_scenario["final_cash"]

print(f"\nBreak-even analysis complete.")
print(f"Optimal Rent/Sell Mix for Break-even: {breakeven_percentage}% Rent / {100 - breakeven_percentage}% Sell")
print(f"Final Cumulative Cash at this mix: ${final_cash_at_breakeven:,.2f}")

# Create the scenario file
import json

breakeven_config = default_params.copy()
breakeven_config["rent_percentage"] = breakeven_percentage

with open("hybrid_breakeven_scenario.json", "w") as f:
    json.dump(breakeven_config, f, indent=4)

print(f"\nSuccessfully created hybrid_breakeven_scenario.json with {breakeven_percentage}% rent.")

