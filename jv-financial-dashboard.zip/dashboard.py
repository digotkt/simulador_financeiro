import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import json
from datetime import datetime
import io

# Page configuration
st.set_page_config(
    page_title="JV Financial Simulation Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .metric-card {
        background-color: #f0f2f6;
        padding: 15px;
        border-radius: 5px;
        margin: 10px 0;
    }
    .warning-red {
        color: #ff4b4b;
        font-weight: bold;
    }
    .warning-yellow {
        color: #ffa500;
        font-weight: bold;
    }
    .success-green {
        color: #00cc00;
        font-weight: bold;
    }
    .stAlert {
        margin-top: 10px;
    }
</style>
""", unsafe_allow_html=True)

# ============================================================================
# FINANCIAL CALCULATION ENGINE
# ============================================================================

def calculate_overhead_per_unit(overhead_monthly, cycle_months, target_simultaneous):
    """Calculate overhead allocation per unit"""
    return (overhead_monthly * cycle_months) / target_simultaneous

def calculate_investor_principal(land_cost, first_draw, overhead_per_unit):
    """Calculate investor principal (P)"""
    return land_cost + first_draw + overhead_per_unit

def calculate_quarterly_reserve(P):
    """Calculate quarterly reserve (4.5% of P)"""
    return 0.045 * P

def calculate_gross_fundraising(P, reserve, use_reserve=True):
    """Calculate gross fundraising (G)"""
    if use_reserve:
        return (P + reserve) / 0.95
    else:
        return P / 0.95

def calculate_cap_fee(G, cap_fee_rate):
    """Calculate capitalization fee"""
    return G * cap_fee_rate

def calculate_mortgage_payment(loan_amount, annual_rate, term_years):
    """Calculate monthly mortgage payment using PMT formula (Excel-compatible)"""
    if loan_amount == 0 or annual_rate == 0:
        return 0
    monthly_rate = annual_rate / 12
    n_payments = term_years * 12
    # PMT formula: P * (r * (1+r)^n) / ((1+r)^n - 1)
    payment = loan_amount * (monthly_rate * (1 + monthly_rate)**n_payments) / ((1 + monthly_rate)**n_payments - 1)
    return payment

def calculate_rent_metrics(params, P, ltv):
    """Calculate all rent-related metrics"""
    sale_price = params['sale_price']
    build_cost = params['build_cost']
    first_draw = params['first_draw']
    rent_monthly = params['rent_monthly']
    monthly_non_debt_costs = params['monthly_non_debt_costs']
    mortgage_annual_rate = params['mortgage_annual_rate']
    mortgage_term_years = params['mortgage_term_years']
    refi_cost_rate = params['refi_cost_rate']
    
    # Refinancing calculations
    loan_amount = ltv * sale_price
    refi_costs = refi_cost_rate * loan_amount
    mortgage_payment = calculate_mortgage_payment(loan_amount, mortgage_annual_rate, mortgage_term_years)
    
    # NOI and DSCR
    noi = rent_monthly - monthly_non_debt_costs
    dscr = noi / mortgage_payment if mortgage_payment > 0 else 0
    
    # Monthly cash flow
    monthly_cash_flow = rent_monthly - (mortgage_payment + monthly_non_debt_costs)
    
    # Net refi cash
    remaining_build_cost = build_cost - first_draw
    net_refi_cash = loan_amount - refi_costs - remaining_build_cost
    
    # Investor due at final (month 12)
    investor_due_final = P * 1.115
    
    # Refi shortfall (positive = shortfall, negative = surplus)
    refi_shortfall = investor_due_final - net_refi_cash
    
    return {
        'loan_amount': loan_amount,
        'refi_costs': refi_costs,
        'mortgage_payment': mortgage_payment,
        'noi': noi,
        'dscr': dscr,
        'monthly_cash_flow': monthly_cash_flow,
        'net_refi_cash': net_refi_cash,
        'investor_due_final': investor_due_final,
        'refi_shortfall': refi_shortfall,
        'remaining_build_cost': remaining_build_cost
    }

def calculate_sell_metrics(params, P):
    """Calculate sell scenario metrics"""
    sale_price = params['sale_price']
    build_cost = params['build_cost']
    land_cost = params['land_cost']
    closing_cost_rate = params['closing_cost_rate']
    
    # Total costs
    total_cost = land_cost + build_cost
    
    # Closing costs
    closing_costs = sale_price * closing_cost_rate
    
    # Net proceeds
    net_proceeds = sale_price - closing_costs - total_cost
    
    # Investor due at final
    investor_due_final = P * 1.115
    
    # Profit after investor payment
    profit_after_investor = net_proceeds - investor_due_final
    
    # ROI
    roi = (profit_after_investor / investor_due_final * 100) if investor_due_final > 0 else 0
    
    return {
        'total_cost': total_cost,
        'closing_costs': closing_costs,
        'net_proceeds': net_proceeds,
        'investor_due_final': investor_due_final,
        'profit_after_investor': profit_after_investor,
        'roi': roi
    }

def simulate_portfolio_60_months(params, rent_percentage):
    """
    Simulate 60-month portfolio with mixed rent/sell strategy
    Returns detailed month-by-month breakdown
    """
    cycle_months = params['cycle_months']
    target_simultaneous = params['target_simultaneous']
    overhead_monthly = params['overhead_monthly']
    
    # Calculate unit economics
    overhead_per_unit = calculate_overhead_per_unit(overhead_monthly, cycle_months, target_simultaneous)
    P = calculate_investor_principal(params['land_cost'], params['first_draw'], overhead_per_unit)
    reserve = calculate_quarterly_reserve(P)
    G = calculate_gross_fundraising(P, reserve, use_reserve=True)
    cap_fee = calculate_cap_fee(G, params['cap_fee_rate'])
    
    # Initialize tracking
    months = 60
    data = []
    
    # Track cohorts (groups of units starting each month)
    cohorts = []
    active_rents = 0
    cumulative_cash = 0
    
    for month in range(1, months + 1):
        month_data = {
            'month': month,
            'land_fundraising': 0,
            'draw_fundraising': 0,
            'fee_fundraising': 0,
            'reserve_fundraising': 0,
            'total_fundraising': 0,
            'overhead_cost': overhead_monthly,
            'investor_distributions': 0,
            'refi_proceeds': 0,
            'sale_proceeds': 0,
            'active_constructions': 0,
            'deliveries': 0,
            'active_rents': 0,
            'rent_income': 0,
            'mortgage_payments': 0,
            'operating_costs': 0,
            'monthly_net_cash': 0,
            'cumulative_cash': 0
        }
        
        # Start new cohort each month until we reach steady state
        if month <= target_simultaneous:
            # Fundraising for new unit
            month_data['land_fundraising'] = params['land_cost']
            month_data['draw_fundraising'] = params['first_draw']
            month_data['fee_fundraising'] = cap_fee
            month_data['reserve_fundraising'] = reserve
            month_data['total_fundraising'] = G
            
            # Create new cohort
            cohorts.append({
                'start_month': month,
                'completion_month': month + cycle_months,
                'is_rent': np.random.random() < (rent_percentage / 100),
                'P': P,
                'delivered': False
            })
        
        # Count active constructions
        month_data['active_constructions'] = sum(
            1 for c in cohorts 
            if c['start_month'] <= month < c['completion_month']
        )
        
        # Check for deliveries and distributions
        for cohort in cohorts:
            # Quarterly distributions (months 3, 6, 9 of construction)
            months_in_construction = month - cohort['start_month'] + 1
            if months_in_construction in [3, 6, 9]:
                month_data['investor_distributions'] += cohort['P'] * 0.015
            
            # Completion at month 12 (month 10 construction + 2 months for final)
            if month == cohort['start_month'] + 11 and not cohort['delivered']:
                cohort['delivered'] = True
                month_data['deliveries'] += 1
                
                if cohort['is_rent']:
                    # Refinancing
                    rent_metrics = calculate_rent_metrics(params, cohort['P'], params['ltv_default'])
                    month_data['refi_proceeds'] += rent_metrics['net_refi_cash']
                    month_data['investor_distributions'] += cohort['P'] * 0.115  # Final distribution
                    active_rents += 1
                    cohort['mortgage_payment'] = rent_metrics['mortgage_payment']
                else:
                    # Sale
                    sell_metrics = calculate_sell_metrics(params, cohort['P'])
                    month_data['sale_proceeds'] += sell_metrics['net_proceeds']
                    month_data['investor_distributions'] += cohort['P'] * 0.115  # Final distribution
        
        # Rental income and expenses
        month_data['active_rents'] = active_rents
        month_data['rent_income'] = active_rents * params['rent_monthly']
        month_data['mortgage_payments'] = sum(
            c.get('mortgage_payment', 0) for c in cohorts if c.get('delivered') and c['is_rent']
        )
        month_data['operating_costs'] = active_rents * params['monthly_non_debt_costs']
        
        # Calculate monthly net cash
        month_data['monthly_net_cash'] = (
            month_data['total_fundraising'] +
            month_data['refi_proceeds'] +
            month_data['sale_proceeds'] +
            month_data['rent_income'] -
            month_data['overhead_cost'] -
            month_data['investor_distributions'] -
            month_data['mortgage_payments'] -
            month_data['operating_costs']
        )
        
        cumulative_cash += month_data['monthly_net_cash']
        month_data['cumulative_cash'] = cumulative_cash
        
        data.append(month_data)
    
    df = pd.DataFrame(data)
    
    # Find self-sustainability point (when cumulative cash becomes positive and stays positive)
    sustainability_month = None
    for i in range(len(df)):
        if df.iloc[i]['cumulative_cash'] > 0:
            # Check if it stays positive for next 3 months
            if i + 3 < len(df):
                if all(df.iloc[i:i+4]['cumulative_cash'] > 0):
                    sustainability_month = df.iloc[i]['month']
                    break
            else:
                sustainability_month = df.iloc[i]['month']
                break
    
    return df, sustainability_month, P, G, cap_fee, overhead_per_unit

# ============================================================================
# STREAMLIT APP
# ============================================================================

def main():
    st.title("📊 JV Financial Simulation Dashboard")
    st.markdown("**Essence Capital - Build-to-Rent / Build-to-Sell / Hybrid Model**")
    
    # Sidebar - Input Parameters
    st.sidebar.header("⚙️ Simulation Parameters")
    
    # Fixed parameters section
    st.sidebar.subheader("Fixed Parameters")
    sale_price = st.sidebar.number_input("Sale Price ($)", value=350000, step=1000, format="%d")
    build_cost = st.sidebar.number_input("Build Cost ($)", value=225000, step=1000, format="%d")
    land_cost = st.sidebar.number_input("Land Cost ($)", value=50000, step=1000, format="%d")
    first_draw = st.sidebar.number_input("First Draw ($)", value=45000, step=1000, format="%d")
    closing_cost_rate = st.sidebar.slider("Closing Cost Rate (%)", 0.0, 20.0, 8.0, 0.1) / 100
    cycle_months = st.sidebar.number_input("Construction Cycle (months)", value=10, step=1, format="%d")
    overhead_monthly = st.sidebar.number_input("Monthly Overhead ($)", value=10000, step=1000, format="%d")
    cap_fee_rate = st.sidebar.slider("Cap Fee Rate (%)", 0.0, 10.0, 5.0, 0.1) / 100
    
    st.sidebar.subheader("Variable Parameters")
    target_simultaneous = st.sidebar.slider("Target Simultaneous Works", 10, 40, 20, 1)
    investor_apr = st.sidebar.slider("Investor APR (%)", 10.0, 25.0, 15.0, 0.5) / 100
    
    st.sidebar.subheader("Refinancing Parameters")
    ltv_default = st.sidebar.slider("LTV Ratio", 0.50, 0.80, 0.70, 0.01)
    rent_monthly = st.sidebar.number_input("Monthly Rent ($)", value=2300, step=100, format="%d")
    mortgage_annual_rate = st.sidebar.slider("Mortgage Annual Rate (%)", 5.0, 12.0, 7.5, 0.1) / 100
    mortgage_term_years = st.sidebar.number_input("Mortgage Term (years)", value=30, step=1, format="%d")
    monthly_non_debt_costs = st.sidebar.number_input("Monthly Non-Debt Costs ($)", value=300, step=50, format="%d")
    refi_cost_rate = st.sidebar.slider("Refi Cost Rate (%)", 0.0, 10.0, 3.0, 0.1) / 100
    
    st.sidebar.subheader("Portfolio Mix")
    rent_percentage = st.sidebar.slider("Rent Percentage (%)", 0, 100, 50, 5)
    
    # Collect all parameters
    params = {
        'sale_price': sale_price,
        'build_cost': build_cost,
        'land_cost': land_cost,
        'first_draw': first_draw,
        'closing_cost_rate': closing_cost_rate,
        'cycle_months': cycle_months,
        'overhead_monthly': overhead_monthly,
        'cap_fee_rate': cap_fee_rate,
        'target_simultaneous': target_simultaneous,
        'investor_apr': investor_apr,
        'ltv_default': ltv_default,
        'rent_monthly': rent_monthly,
        'mortgage_annual_rate': mortgage_annual_rate,
        'mortgage_term_years': mortgage_term_years,
        'monthly_non_debt_costs': monthly_non_debt_costs,
        'refi_cost_rate': refi_cost_rate,
        'rent_percentage': rent_percentage
    }
    
    # Calculate unit economics
    overhead_per_unit = calculate_overhead_per_unit(overhead_monthly, cycle_months, target_simultaneous)
    P = calculate_investor_principal(land_cost, first_draw, overhead_per_unit)
    reserve = calculate_quarterly_reserve(P)
    G = calculate_gross_fundraising(P, reserve, use_reserve=True)
    cap_fee = calculate_cap_fee(G, cap_fee_rate)
    
    # Main content tabs
    tab1, tab2, tab3, tab4 = st.tabs(["📈 Unit Economics", "🏢 Portfolio Simulation", "📊 LTV Analysis", "💾 Export & Scenarios"])
    
    # ========================================================================
    # TAB 1: UNIT ECONOMICS
    # ========================================================================
    with tab1:
        st.header("Unit Economics Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("🏠 Build-to-Rent Scenario")
            
            rent_metrics = calculate_rent_metrics(params, P, ltv_default)
            
            # Display key metrics
            st.metric("Investor Principal (P)", f"${P:,.2f}")
            st.metric("Quarterly Reserve", f"${reserve:,.2f}")
            st.metric("Gross Fundraising (G)", f"${G:,.2f}")
            st.metric("Cap Fee (5%)", f"${cap_fee:,.2f}")
            
            st.markdown("---")
            st.markdown("**Refinancing Metrics**")
            st.metric("Loan Amount (LTV)", f"${rent_metrics['loan_amount']:,.2f}")
            st.metric("Refi Costs", f"${rent_metrics['refi_costs']:,.2f}")
            st.metric("Net Refi Cash", f"${rent_metrics['net_refi_cash']:,.2f}")
            
            st.markdown("---")
            st.markdown("**Operating Metrics**")
            st.metric("Monthly Mortgage Payment", f"${rent_metrics['mortgage_payment']:,.2f}")
            st.metric("NOI (Net Operating Income)", f"${rent_metrics['noi']:,.2f}")
            
            # DSCR with color coding
            dscr_value = rent_metrics['dscr']
            if dscr_value < 1.20:
                st.markdown(f"**DSCR:** <span class='warning-red'>{dscr_value:.3f} ⚠️ Below 1.20!</span>", unsafe_allow_html=True)
            else:
                st.markdown(f"**DSCR:** <span class='success-green'>{dscr_value:.3f} ✓</span>", unsafe_allow_html=True)
            
            st.metric("Monthly Cash Flow", f"${rent_metrics['monthly_cash_flow']:,.2f}")
            
            # Refi Shortfall with color coding
            shortfall = rent_metrics['refi_shortfall']
            if shortfall > 0:
                st.markdown(f"**Refi Shortfall:** <span class='warning-red'>${shortfall:,.2f} ⚠️ Shortfall!</span>", unsafe_allow_html=True)
            else:
                st.markdown(f"**Refi Surplus:** <span class='success-green'>${abs(shortfall):,.2f} ✓</span>", unsafe_allow_html=True)
        
        with col2:
            st.subheader("💰 Build-to-Sell Scenario")
            
            sell_metrics = calculate_sell_metrics(params, P)
            
            # Display key metrics
            st.metric("Investor Principal (P)", f"${P:,.2f}")
            st.metric("Quarterly Reserve", f"${reserve:,.2f}")
            st.metric("Gross Fundraising (G)", f"${G:,.2f}")
            st.metric("Cap Fee (5%)", f"${cap_fee:,.2f}")
            
            st.markdown("---")
            st.markdown("**Sale Metrics**")
            st.metric("Sale Price", f"${sale_price:,.2f}")
            st.metric("Total Cost", f"${sell_metrics['total_cost']:,.2f}")
            st.metric("Closing Costs", f"${sell_metrics['closing_costs']:,.2f}")
            st.metric("Net Proceeds", f"${sell_metrics['net_proceeds']:,.2f}")
            
            st.markdown("---")
            st.markdown("**Profitability**")
            st.metric("Investor Due (Final)", f"${sell_metrics['investor_due_final']:,.2f}")
            
            profit = sell_metrics['profit_after_investor']
            if profit > 0:
                st.markdown(f"**Profit After Investor:** <span class='success-green'>${profit:,.2f} ✓</span>", unsafe_allow_html=True)
            else:
                st.markdown(f"**Loss After Investor:** <span class='warning-red'>${abs(profit):,.2f} ⚠️</span>", unsafe_allow_html=True)
            
            st.metric("ROI", f"{sell_metrics['roi']:.2f}%")
    
    # ========================================================================
    # TAB 2: PORTFOLIO SIMULATION
    # ========================================================================
    with tab2:
        st.header("60-Month Portfolio Simulation")
        st.markdown(f"**Mix: {rent_percentage}% Rent / {100-rent_percentage}% Sell**")
        
        # Run simulation
        df_portfolio, sustainability_month, P_sim, G_sim, fee_sim, overhead_unit = simulate_portfolio_60_months(params, rent_percentage)
        
        # Display sustainability point
        if sustainability_month:
            st.success(f"✅ **Self-Sustainability Point: Month {sustainability_month}**")
        else:
            st.warning("⚠️ **Portfolio does not reach self-sustainability within 60 months**")
        
        # Key metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Fundraising", f"${df_portfolio['total_fundraising'].sum():,.0f}")
        with col2:
            st.metric("Total Distributions", f"${df_portfolio['investor_distributions'].sum():,.0f}")
        with col3:
            st.metric("Final Cumulative Cash", f"${df_portfolio['cumulative_cash'].iloc[-1]:,.0f}")
        with col4:
            st.metric("Total Deliveries", f"{df_portfolio['deliveries'].sum():.0f}")
        
        # Chart 1: Monthly Fundraising (Stacked)
        st.subheader("Monthly Fundraising Breakdown")
        fig_fundraising = go.Figure()
        fig_fundraising.add_trace(go.Scatter(
            x=df_portfolio['month'], y=df_portfolio['land_fundraising'],
            mode='lines', name='Land', stackgroup='one', fillcolor='#1f77b4'
        ))
        fig_fundraising.add_trace(go.Scatter(
            x=df_portfolio['month'], y=df_portfolio['draw_fundraising'],
            mode='lines', name='First Draw', stackgroup='one', fillcolor='#ff7f0e'
        ))
        fig_fundraising.add_trace(go.Scatter(
            x=df_portfolio['month'], y=df_portfolio['fee_fundraising'],
            mode='lines', name='Fee', stackgroup='one', fillcolor='#2ca02c'
        ))
        fig_fundraising.add_trace(go.Scatter(
            x=df_portfolio['month'], y=df_portfolio['reserve_fundraising'],
            mode='lines', name='Reserve', stackgroup='one', fillcolor='#d62728'
        ))
        fig_fundraising.update_layout(
            xaxis_title="Month",
            yaxis_title="Amount ($)",
            hovermode='x unified',
            height=400
        )
        st.plotly_chart(fig_fundraising, use_container_width=True)
        
        # Chart 2: Active Constructions vs Target
        st.subheader("Active Constructions vs Target")
        fig_constructions = go.Figure()
        fig_constructions.add_trace(go.Scatter(
            x=df_portfolio['month'], y=df_portfolio['active_constructions'],
            mode='lines', name='Active Constructions', line=dict(color='blue', width=2)
        ))
        fig_constructions.add_trace(go.Scatter(
            x=df_portfolio['month'], y=[target_simultaneous] * len(df_portfolio),
            mode='lines', name='Target', line=dict(color='red', dash='dash', width=2)
        ))
        fig_constructions.update_layout(
            xaxis_title="Month",
            yaxis_title="Number of Units",
            hovermode='x unified',
            height=400
        )
        st.plotly_chart(fig_constructions, use_container_width=True)
        
        # Chart 3: Cumulative Cash Flow
        st.subheader("Cumulative Cash Flow")
        fig_cash = go.Figure()
        fig_cash.add_trace(go.Scatter(
            x=df_portfolio['month'], y=df_portfolio['cumulative_cash'],
            mode='lines', name='Cumulative Cash', line=dict(color='green', width=2),
            fill='tozeroy'
        ))
        if sustainability_month:
            fig_cash.add_vline(x=sustainability_month, line_dash="dash", line_color="orange",
                              annotation_text=f"Sustainability (Month {sustainability_month})")
        fig_cash.update_layout(
            xaxis_title="Month",
            yaxis_title="Cumulative Cash ($)",
            hovermode='x unified',
            height=400
        )
        st.plotly_chart(fig_cash, use_container_width=True)
        
        # Chart 4: Deliveries and Active Rents
        st.subheader("Deliveries and Active Rental Units")
        fig_deliveries = make_subplots(specs=[[{"secondary_y": True}]])
        fig_deliveries.add_trace(
            go.Bar(x=df_portfolio['month'], y=df_portfolio['deliveries'], name='Deliveries'),
            secondary_y=False
        )
        fig_deliveries.add_trace(
            go.Scatter(x=df_portfolio['month'], y=df_portfolio['active_rents'], 
                      name='Active Rents', line=dict(color='orange', width=2)),
            secondary_y=True
        )
        fig_deliveries.update_xaxes(title_text="Month")
        fig_deliveries.update_yaxes(title_text="Deliveries", secondary_y=False)
        fig_deliveries.update_yaxes(title_text="Active Rental Units", secondary_y=True)
        fig_deliveries.update_layout(hovermode='x unified', height=400)
        st.plotly_chart(fig_deliveries, use_container_width=True)
    
    # ========================================================================
    # TAB 3: LTV ANALYSIS
    # ========================================================================
    with tab3:
        st.header("LTV Sensitivity Analysis")
        st.markdown("Analyze how different LTV ratios affect refinancing metrics")
        
        # Generate LTV range
        ltv_range = np.arange(0.50, 0.81, 0.01)
        ltv_analysis = []
        
        for ltv in ltv_range:
            metrics = calculate_rent_metrics(params, P, ltv)
            ltv_analysis.append({
                'ltv': ltv,
                'dscr': metrics['dscr'],
                'monthly_cash_flow': metrics['monthly_cash_flow'],
                'refi_shortfall': metrics['refi_shortfall']
            })
        
        df_ltv = pd.DataFrame(ltv_analysis)
        
        # Chart 1: DSCR vs LTV
        st.subheader("DSCR vs LTV Ratio")
        fig_dscr = go.Figure()
        fig_dscr.add_trace(go.Scatter(
            x=df_ltv['ltv'], y=df_ltv['dscr'],
            mode='lines', name='DSCR', line=dict(color='blue', width=2)
        ))
        fig_dscr.add_hline(y=1.20, line_dash="dash", line_color="red",
                          annotation_text="Minimum DSCR (1.20)")
        fig_dscr.update_layout(
            xaxis_title="LTV Ratio",
            yaxis_title="DSCR",
            hovermode='x unified',
            height=400
        )
        st.plotly_chart(fig_dscr, use_container_width=True)
        
        # Chart 2: Monthly Cash Flow vs LTV
        st.subheader("Monthly Cash Flow vs LTV Ratio")
        fig_cf = go.Figure()
        fig_cf.add_trace(go.Scatter(
            x=df_ltv['ltv'], y=df_ltv['monthly_cash_flow'],
            mode='lines', name='Monthly Cash Flow', line=dict(color='green', width=2),
            fill='tozeroy'
        ))
        fig_cf.update_layout(
            xaxis_title="LTV Ratio",
            yaxis_title="Monthly Cash Flow ($)",
            hovermode='x unified',
            height=400
        )
        st.plotly_chart(fig_cf, use_container_width=True)
        
        # Chart 3: Refi Shortfall vs LTV
        st.subheader("Refi Shortfall vs LTV Ratio")
        fig_shortfall = go.Figure()
        
        # Color code: red for positive (shortfall), green for negative (surplus)
        colors = ['red' if x > 0 else 'green' for x in df_ltv['refi_shortfall']]
        
        fig_shortfall.add_trace(go.Scatter(
            x=df_ltv['ltv'], y=df_ltv['refi_shortfall'],
            mode='lines', name='Refi Shortfall', line=dict(color='purple', width=2),
            fill='tozeroy'
        ))
        fig_shortfall.add_hline(y=0, line_dash="dash", line_color="black",
                               annotation_text="Break-even")
        
        # Find zero crossing
        zero_crossing = df_ltv[df_ltv['refi_shortfall'].abs() == df_ltv['refi_shortfall'].abs().min()]
        if not zero_crossing.empty:
            ltv_breakeven = zero_crossing.iloc[0]['ltv']
            fig_shortfall.add_vline(x=ltv_breakeven, line_dash="dot", line_color="orange",
                                   annotation_text=f"Break-even LTV: {ltv_breakeven:.2f}")
        
        fig_shortfall.update_layout(
            xaxis_title="LTV Ratio",
            yaxis_title="Refi Shortfall ($)",
            hovermode='x unified',
            height=400
        )
        st.plotly_chart(fig_shortfall, use_container_width=True)
        
        # Display optimal LTV
        optimal_ltv = df_ltv[df_ltv['refi_shortfall'] <= 0]['ltv'].min()
        if pd.notna(optimal_ltv):
            st.success(f"✅ **Minimum LTV for zero shortfall: {optimal_ltv:.2%}**")
        else:
            st.warning("⚠️ **No LTV ratio in range eliminates shortfall**")
    
    # ========================================================================
    # TAB 4: EXPORT & SCENARIOS
    # ========================================================================
    with tab4:
        st.header("Export & Scenario Management")
        
        # Scenario presets
        st.subheader("📋 Scenario Presets")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("100% Rent Scenario"):
                st.session_state['rent_percentage'] = 100
                st.experimental_rerun()
        
        with col2:
            if st.button("100% Sell Scenario"):
                st.session_state['rent_percentage'] = 0
                st.experimental_rerun()
        
        with col3:
            if st.button("50/50 Hybrid Scenario"):
                st.session_state['rent_percentage'] = 50
                st.experimental_rerun()
        
        st.markdown("---")
        
        # Export current parameters
        st.subheader("💾 Export Current Configuration")
        
        config_json = json.dumps(params, indent=2)
        st.download_button(
            label="Download Parameters (JSON)",
            data=config_json,
            file_name=f"jv_simulation_config_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            mime="application/json"
        )
        
        # Export portfolio data
        st.subheader("📊 Export Portfolio Data")
        
        csv_buffer = io.StringIO()
        df_portfolio.to_csv(csv_buffer, index=False)
        st.download_button(
            label="Download Portfolio Data (CSV)",
            data=csv_buffer.getvalue(),
            file_name=f"jv_portfolio_simulation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
        
        # Export LTV analysis
        st.subheader("📈 Export LTV Analysis")
        
        ltv_csv_buffer = io.StringIO()
        df_ltv.to_csv(ltv_csv_buffer, index=False)
        st.download_button(
            label="Download LTV Analysis (CSV)",
            data=ltv_csv_buffer.getvalue(),
            file_name=f"jv_ltv_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
        
        # Summary report
        st.subheader("📄 Summary Report")
        
        summary_report = f"""
# JV Financial Simulation Summary Report
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Configuration
- Rent/Sell Mix: {rent_percentage}% Rent / {100-rent_percentage}% Sell
- Target Simultaneous Works: {target_simultaneous}
- LTV Ratio: {ltv_default:.2%}
- Investor APR: {investor_apr:.2%}

## Unit Economics
- Investor Principal (P): ${P:,.2f}
- Gross Fundraising (G): ${G:,.2f}
- Cap Fee: ${cap_fee:,.2f}
- Overhead per Unit: ${overhead_per_unit:,.2f}

## Build-to-Rent Metrics
- DSCR: {rent_metrics['dscr']:.3f}
- Monthly Cash Flow: ${rent_metrics['monthly_cash_flow']:,.2f}
- Refi Shortfall: ${rent_metrics['refi_shortfall']:,.2f}

## Build-to-Sell Metrics
- Net Proceeds: ${sell_metrics['net_proceeds']:,.2f}
- Profit After Investor: ${sell_metrics['profit_after_investor']:,.2f}
- ROI: {sell_metrics['roi']:.2f}%

## Portfolio Simulation (60 months)
- Total Fundraising: ${df_portfolio['total_fundraising'].sum():,.0f}
- Total Distributions: ${df_portfolio['investor_distributions'].sum():,.0f}
- Final Cumulative Cash: ${df_portfolio['cumulative_cash'].iloc[-1]:,.0f}
- Self-Sustainability Month: {sustainability_month if sustainability_month else 'Not achieved'}
- Total Deliveries: {df_portfolio['deliveries'].sum():.0f}
"""
        
        st.download_button(
            label="Download Summary Report (TXT)",
            data=summary_report,
            file_name=f"jv_summary_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
            mime="text/plain"
        )

if __name__ == "__main__":
    main()

